module.exports = {
    mogoUrl: "mongodb+srv://srh:En3PH2Vn5YlC1rNn@cluster0.aaqemgv.mongodb.net/",
    jwtkey: "radneriv"
}
// LaXFQzWXP6WnuQo3
////134.155.24.234/32